| `Version` | `Update Notes`                                                                                                            |
|-----------|---------------------------------------------------------------------------------------------------------------------------|
| 1.0.5     | - Courtesy Update for Valheim 0.217.46. Just bumping the version and updating the last updated date. Nothing to see here. |
| 1.0.4     | - Update for Valheim 0.217.22                                                                                             |
| 1.0.3     | - Set the priority to last, hopefully providing compatibility with more mods.                                             |
| 1.0.2     | - Remove more debug stuff                                                                                                 |
| 1.0.1     | - Remove debug stuff I missed                                                                                             |
| 1.0.0     | - Initial Release                                                                                                         |